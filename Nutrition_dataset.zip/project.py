import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns

#Import the CSV File
df=pd.read_csv("C:\\Users\\Yashika malik\\Downloads\\Nutrition_dataset.csv")
print(df)
# Display basic info
df.info()
df.head()
df.tail()
df.shape
df.describe()
df.columns()


#1. Handle missing Data, 
#Count missing values
missing = df.isnull().sum()
#Fill or drop
df_cleaned = df.dropna(subset=['Data_Value'])

#2.Calculate Statical Metrics
# Filter for obesity-related rows
# Drop missing values and get numpy array
# NumPy stats
obesity_df = df[df['Question'] == 'Percent of adults aged 18 years and older who have obesity']
obesity_values = obesity_df['Data_Value'].dropna().values
mean_obesity = np.mean(obesity_values)
median_obesity = np.median(obesity_values)
std_obesity = np.std(obesity_values)
print(f"Mean Obesity Rate: {mean_obesity:.2f}%")
print(f"Median Obesity Rate: {median_obesity:.2f}%")
print(f"Standard Deviation: {std_obesity:.2f}")

#3. Heatmap - Health Question Correction 
df.columns = df.columns.str.strip().str.lower().str.replace(' ', '_')
pivot_df = df.pivot_table(
    values='data_value',
    index=['locationdesc', 'yearstart'],  # fixed: was 'Year'
    columns='question'
    )
pivot_df.dropna(axis=1, how='all', inplace=True)
correlation = pivot_df.corr()
plt.figure(figsize=(14, 10))
sns.heatmap(correlation, cmap='coolwarm', center=0, annot=True, fmt=".2f", linewidths=0.5)
plt.title('Correlation Between Different Health Metrics')
plt.xticks(rotation=90)
plt.yticks(rotation=0)
plt.show()

#4.Bar chart - Average Obestiy Rate by state
df.columns = df.columns.str.strip().str.lower().str.replace(' ', '_')
obesity_df = df[df['question'] == 'Percent of adults aged 18 years and older who have obesity']
state_obesity = obesity_df.groupby('locationdesc')['data_value'].mean().sort_values(ascending=False)
plt.figure(figsize=(12, 6))
state_obesity.plot(kind='bar', color='blue')
plt.title('Average Obesity Rate by State')
plt.ylabel('Obesity Rate (%)')
plt.xticks(rotation=90)
plt.tight_layout()
plt.show()

#5.boxplot - Distribution of Health Data Value by Age Group
df.columns = df.columns.str.strip().str.lower().str.replace(' ', '_')
df = df.dropna(subset=['age(years)', 'data_value'])
plt.figure(figsize=(12, 6))
sns.boxplot(data=df, x='age(years)', y='data_value', hue='age(years)', palette='pastel')
plt.title('Distribution of Health Data Values by Age Group', fontsize=14)
plt.xlabel('Age Group')
plt.ylabel('Data Value (%)')
plt.xticks(rotation=45)
plt.legend([],[], frameon=False)  
plt.tight_layout()
plt.show()

#6.Donut chart - Top 10 Most Common Health Question
df.columns = df.columns.str.strip().str.lower().str.replace(' ', '_')
question_counts = df['question'].value_counts().head(10)
colors = plt.cm.tab10.colors 
plt.figure(figsize=(8, 8))
plt.pie(
    question_counts,
    labels=question_counts.index,
    autopct='%1.1f%%',
    startangle=90,
    colors=colors,
    wedgeprops={'width': 0.4}  
)
centre_circle = plt.Circle((0, 0), 0.70, fc='white')
plt.gca().add_artist(centre_circle)
plt.title("Top 10 Most Common Health Questions", fontsize=14)
plt.show()

#7.scatter plot - Average BMI
df.columns = df.columns.str.lower().str.replace(' ', '_')
bmi_df = df[df['question'] == 'BMI']
avg_bmi = bmi_df.groupby('yearstart')['data_value'].mean().reset_index()
print(avg_bmi)
plt.plot(avg_bmi['yearstart'], avg_bmi['data_value'], marker='o')
plt.title("Average BMI Over the Years")
plt.xlabel("Year")
plt.ylabel("Average BMI (%)")
plt.grid(True)
plt.show()









