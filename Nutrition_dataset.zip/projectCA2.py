Python 3.12.0 (tags/v3.12.0:0fb18b0, Oct  2 2023, 13:03:39) [MSC v.1935 64 bit (AMD64)] on win32
Type "help", "copyright", "credits" or "license()" for more information.

= RESTART: C:\Users\Yashika malik\AppData\Local\Programs\Python\Python312\project.py
        YearStart  YearEnd  ... StratificationCategoryId1 StratificationID1
0            2011     2011  ...                      RACE         RACE2PLUS
1            2011     2011  ...                      RACE           RACEOTH
2            2011     2011  ...                       SEX            FEMALE
3            2011     2011  ...                     AGEYR         AGEYR3544
4            2011     2011  ...                       INC           INC1525
...           ...      ...  ...                       ...               ...
104267       2023     2023  ...                       EDU         EDUHSGRAD
104268       2023     2023  ...                     AGEYR       AGEYR65PLUS
104269       2023     2023  ...                       INC             INCNR
104270       2023     2023  ...                       EDU             EDUHS
104271       2023     2023  ...                     AGEYR         AGEYR5564

[104272 rows x 33 columns]
df.info()
<class 'pandas.core.frame.DataFrame'>
RangeIndex: 104272 entries, 0 to 104271
Data columns (total 33 columns):
 #   Column                      Non-Null Count   Dtype  
---  ------                      --------------   -----  
 0   YearStart                   104272 non-null  int64  
 1   YearEnd                     104272 non-null  int64  
 2   LocationAbbr                104272 non-null  object 
 3   LocationDesc                104272 non-null  object 
 4   Datasource                  104272 non-null  object 
 5   Class                       104272 non-null  object 
 6   Topic                       104272 non-null  object 
 7   Question                    104272 non-null  object 
 8   Data_Value_Unit             88872 non-null   float64
 9   Data_Value_Type             104272 non-null  object 
 10  Data_Value                  93505 non-null   float64
 11  Data_Value_Alt              93505 non-null   float64
 12  Data_Value_Footnote_Symbol  10767 non-null   object 
 13  Data_Value_Footnote         10767 non-null   object 
 14  Low_Confidence_Limit        93505 non-null   float64
 15  High_Confidence_Limit       93505 non-null   float64
 16  Sample_Size                 93505 non-null   float64
 17  Total                       3724 non-null    object 
 18  Age(years)                  22344 non-null   object 
 19  Education                   14896 non-null   object 
 20  Sex                         7448 non-null    object 
 21  Income                      26068 non-null   object 
 22  Race/Ethnicity              29792 non-null   object 
 23  GeoLocation                 102340 non-null  object 
 24  ClassID                     104272 non-null  object 
 25  TopicID                     104272 non-null  object 
 26  QuestionID                  104272 non-null  object 
 27  DataValueTypeID             104272 non-null  object 
 28  LocationID                  104272 non-null  int64  
 29  StratificationCategory1     104272 non-null  object 
 30  Stratification1             104272 non-null  object 
 31  StratificationCategoryId1   104272 non-null  object 
 32  StratificationID1           104272 non-null  object 
dtypes: float64(6), int64(3), object(24)
memory usage: 26.3+ MB
df.head()
   YearStart  YearEnd  ... StratificationCategoryId1 StratificationID1
0       2011     2011  ...                      RACE         RACE2PLUS
1       2011     2011  ...                      RACE           RACEOTH
2       2011     2011  ...                       SEX            FEMALE
3       2011     2011  ...                     AGEYR         AGEYR3544
4       2011     2011  ...                       INC           INC1525

[5 rows x 33 columns]
df.tail()
        YearStart  YearEnd  ... StratificationCategoryId1 StratificationID1
104267       2023     2023  ...                       EDU         EDUHSGRAD
104268       2023     2023  ...                     AGEYR       AGEYR65PLUS
104269       2023     2023  ...                       INC             INCNR
104270       2023     2023  ...                       EDU             EDUHS
104271       2023     2023  ...                     AGEYR         AGEYR5564

[5 rows x 33 columns]
df.shape
(104272, 33)
df.describe()
           YearStart        YearEnd  ...    Sample_Size     LocationID
count  104272.000000  104272.000000  ...   93505.000000  104272.000000
mean     2017.006176    2017.006176  ...    3623.035260      31.053706
std         3.734882       3.734882  ...   18561.958269      17.605859
min      2011.000000    2011.000000  ...      50.000000       1.000000
25%      2014.000000    2014.000000  ...     499.000000      17.000000
50%      2017.000000    2017.000000  ...    1085.000000      30.000000
75%      2020.000000    2020.000000  ...    2397.000000      45.000000
max      2023.000000    2023.000000  ...  476876.000000      78.000000

[8 rows x 9 columns]
df.columns()

df.columns
Index(['YearStart', 'YearEnd', 'LocationAbbr', 'LocationDesc', 'Datasource',
       'Class', 'Topic', 'Question', 'Data_Value_Unit', 'Data_Value_Type',
       'Data_Value', 'Data_Value_Alt', 'Data_Value_Footnote_Symbol',
       'Data_Value_Footnote', 'Low_Confidence_Limit', 'High_Confidence_Limit ',
       'Sample_Size', 'Total', 'Age(years)', 'Education', 'Sex', 'Income',
       'Race/Ethnicity', 'GeoLocation', 'ClassID', 'TopicID', 'QuestionID',
       'DataValueTypeID', 'LocationID', 'StratificationCategory1',
       'Stratification1', 'StratificationCategoryId1', 'StratificationID1'],
      dtype='object')
missing = df.isnull().sum()
missing
YearStart                          0
YearEnd                            0
LocationAbbr                       0
LocationDesc                       0
Datasource                         0
Class                              0
Topic                              0
Question                           0
Data_Value_Unit                15400
Data_Value_Type                    0
Data_Value                     10767
Data_Value_Alt                 10767
Data_Value_Footnote_Symbol     93505
Data_Value_Footnote            93505
Low_Confidence_Limit           10767
High_Confidence_Limit          10767
Sample_Size                    10767
Total                         100548
Age(years)                     81928
Education                      89376
Sex                            96824
Income                         78204
Race/Ethnicity                 74480
GeoLocation                     1932
ClassID                            0
TopicID                            0
QuestionID                         0
DataValueTypeID                    0
LocationID                         0
StratificationCategory1            0
Stratification1                    0
StratificationCategoryId1          0
StratificationID1                  0
dtype: int64
>>> df_cleaned = df.dropna(subset=['Data_Value'])
>>> df_cleaned
        YearStart  YearEnd  ... StratificationCategoryId1 StratificationID1
0            2011     2011  ...                      RACE         RACE2PLUS
1            2011     2011  ...                      RACE           RACEOTH
2            2011     2011  ...                       SEX            FEMALE
3            2011     2011  ...                     AGEYR         AGEYR3544
4            2011     2011  ...                       INC           INC1525
...           ...      ...  ...                       ...               ...
104267       2023     2023  ...                       EDU         EDUHSGRAD
104268       2023     2023  ...                     AGEYR       AGEYR65PLUS
104269       2023     2023  ...                       INC             INCNR
104270       2023     2023  ...                       EDU             EDUHS
104271       2023     2023  ...                     AGEYR         AGEYR5564

[93505 rows x 33 columns]

= RESTART: C:\Users\Yashika malik\AppData\Local\Programs\Python\Python312\project.py
        YearStart  YearEnd  ... StratificationCategoryId1 StratificationID1
0            2011     2011  ...                      RACE         RACE2PLUS
1            2011     2011  ...                      RACE           RACEOTH
2            2011     2011  ...                       SEX            FEMALE
3            2011     2011  ...                     AGEYR         AGEYR3544
4            2011     2011  ...                       INC           INC1525
...           ...      ...  ...                       ...               ...
104267       2023     2023  ...                       EDU         EDUHSGRAD
104268       2023     2023  ...                     AGEYR       AGEYR65PLUS
104269       2023     2023  ...                       INC             INCNR
104270       2023     2023  ...                       EDU             EDUHS
104271       2023     2023  ...                     AGEYR         AGEYR5564

[104272 rows x 33 columns]
Mean Obesity Rate: 31.02%
Median Obesity Rate: 31.50%
Standard Deviation: 7.40

= RESTART: C:\Users\Yashika malik\AppData\Local\Programs\Python\Python312\project.py
        YearStart  YearEnd  ... StratificationCategoryId1 StratificationID1
0            2011     2011  ...                      RACE         RACE2PLUS
1            2011     2011  ...                      RACE           RACEOTH
2            2011     2011  ...                       SEX            FEMALE
3            2011     2011  ...                     AGEYR         AGEYR3544
4            2011     2011  ...                       INC           INC1525
...           ...      ...  ...                       ...               ...
104267       2023     2023  ...                       EDU         EDUHSGRAD
104268       2023     2023  ...                     AGEYR       AGEYR65PLUS
104269       2023     2023  ...                       INC             INCNR
104270       2023     2023  ...                       EDU             EDUHS
104271       2023     2023  ...                     AGEYR         AGEYR5564

[104272 rows x 33 columns]

= RESTART: C:\Users\Yashika malik\AppData\Local\Programs\Python\Python312\project.py
        YearStart  YearEnd  ... StratificationCategoryId1 StratificationID1
0            2011     2011  ...                      RACE         RACE2PLUS
1            2011     2011  ...                      RACE           RACEOTH
2            2011     2011  ...                       SEX            FEMALE
3            2011     2011  ...                     AGEYR         AGEYR3544
4            2011     2011  ...                       INC           INC1525
...           ...      ...  ...                       ...               ...
104267       2023     2023  ...                       EDU         EDUHSGRAD
104268       2023     2023  ...                     AGEYR       AGEYR65PLUS
104269       2023     2023  ...                       INC             INCNR
104270       2023     2023  ...                       EDU             EDUHS
104271       2023     2023  ...                     AGEYR         AGEYR5564

[104272 rows x 33 columns]

= RESTART: C:\Users\Yashika malik\AppData\Local\Programs\Python\Python312\project.py
        YearStart  YearEnd  ... StratificationCategoryId1 StratificationID1
0            2011     2011  ...                      RACE         RACE2PLUS
1            2011     2011  ...                      RACE           RACEOTH
2            2011     2011  ...                       SEX            FEMALE
3            2011     2011  ...                     AGEYR         AGEYR3544
4            2011     2011  ...                       INC           INC1525
...           ...      ...  ...                       ...               ...
104267       2023     2023  ...                       EDU         EDUHSGRAD
104268       2023     2023  ...                     AGEYR       AGEYR65PLUS
104269       2023     2023  ...                       INC             INCNR
104270       2023     2023  ...                       EDU             EDUHS
104271       2023     2023  ...                     AGEYR         AGEYR5564

[104272 rows x 33 columns]

= RESTART: C:\Users\Yashika malik\AppData\Local\Programs\Python\Python312\project.py
        YearStart  YearEnd  ... StratificationCategoryId1 StratificationID1
0            2011     2011  ...                      RACE         RACE2PLUS
1            2011     2011  ...                      RACE           RACEOTH
2            2011     2011  ...                       SEX            FEMALE
3            2011     2011  ...                     AGEYR         AGEYR3544
4            2011     2011  ...                       INC           INC1525
...           ...      ...  ...                       ...               ...
104267       2023     2023  ...                       EDU         EDUHSGRAD
104268       2023     2023  ...                     AGEYR       AGEYR65PLUS
104269       2023     2023  ...                       INC             INCNR
104270       2023     2023  ...                       EDU             EDUHS
104271       2023     2023  ...                     AGEYR         AGEYR5564

[104272 rows x 33 columns]

= RESTART: C:\Users\Yashika malik\AppData\Local\Programs\Python\Python312\project.py
        YearStart  YearEnd  ... StratificationCategoryId1 StratificationID1
0            2011     2011  ...                      RACE         RACE2PLUS
1            2011     2011  ...                      RACE           RACEOTH
2            2011     2011  ...                       SEX            FEMALE
3            2011     2011  ...                     AGEYR         AGEYR3544
4            2011     2011  ...                       INC           INC1525
...           ...      ...  ...                       ...               ...
104267       2023     2023  ...                       EDU         EDUHSGRAD
104268       2023     2023  ...                     AGEYR       AGEYR65PLUS
104269       2023     2023  ...                       INC             INCNR
104270       2023     2023  ...                       EDU             EDUHS
104271       2023     2023  ...                     AGEYR         AGEYR5564

[104272 rows x 33 columns]
Empty DataFrame
Columns: [yearstart, data_value]
Index: []
